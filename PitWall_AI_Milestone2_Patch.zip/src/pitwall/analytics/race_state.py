import pandas as pd

def _secs(series):
    return pd.to_timedelta(series, errors="coerce").dt.total_seconds()

def build_race_state(session):
    laps = session.laps.copy() if getattr(session, "laps", None) is not None else pd.DataFrame()
    weather = getattr(session, "weather_data", None)
    weather = weather.copy() if isinstance(weather, pd.DataFrame) else pd.DataFrame()
    results = getattr(session, "results", None)
    results = results.copy() if isinstance(results, pd.DataFrame) else pd.DataFrame()

    if not laps.empty:
        laps["LapTimeSeconds"] = _secs(laps["LapTime"]) if "LapTime" in laps else pd.NA
    valid = laps.copy()
    if not valid.empty:
        valid = valid[valid["LapTimeSeconds"].notna() & (valid["LapTimeSeconds"] > 0) & (valid["LapTimeSeconds"] < 300)]

    if not valid.empty and "Driver" in valid:
        pace = valid.groupby("Driver")["LapTimeSeconds"].agg(
            ValidLaps="count", MedianLapSeconds="median", MeanLapSeconds="mean",
            StdDevSeconds="std", BestLapSeconds="min"
        ).reset_index()
        pace["MedianGapToFastestSeconds"] = (pace["MedianLapSeconds"] - pace["MedianLapSeconds"].min()).round(3)
        for col in ["MedianLapSeconds", "MeanLapSeconds", "StdDevSeconds", "BestLapSeconds"]:
            pace[col] = pace[col].round(3)
        pace = pace.sort_values("MedianLapSeconds").reset_index(drop=True)
    else:
        pace = pd.DataFrame()

    if not laps.empty and {"Driver", "Stint"}.issubset(laps.columns):
        cols = [c for c in ["Driver", "Team", "Stint", "Compound", "FreshTyre", "TyreLife", "LapNumber", "LapTimeSeconds"] if c in laps]
        df = laps[cols].copy()
        group = [c for c in ["Driver", "Team", "Stint", "Compound", "FreshTyre"] if c in df]
        agg = {}
        if "LapNumber" in df: agg["LapNumber"] = ["min", "max", "count"]
        if "TyreLife" in df: agg["TyreLife"] = ["min", "max"]
        if "LapTimeSeconds" in df: agg["LapTimeSeconds"] = ["median", "min"]
        stints = df.groupby(group, dropna=False).agg(agg)
        stints.columns = ["_".join(str(x) for x in c if str(x)) for c in stints.columns.to_flat_index()]
        stints = stints.reset_index()
    else:
        stints = pd.DataFrame()

    weather_summary = []
    if not weather.empty:
        for col in ["AirTemp", "TrackTemp", "Humidity", "Pressure", "WindSpeed", "Rainfall"]:
            if col in weather:
                values = pd.to_numeric(weather[col], errors="coerce").dropna()
                if not values.empty:
                    weather_summary.append({"Metric": col, "Min": round(values.min(), 2),
                                            "Mean": round(values.mean(), 2), "Max": round(values.max(), 2)})

    result_cols = [c for c in ["Abbreviation", "FullName", "TeamName", "GridPosition", "Position", "ClassifiedPosition", "Points", "Status"] if c in results]
    result_table = results[result_cols].copy() if result_cols else pd.DataFrame()

    event_info = {}
    event = getattr(session, "event", None)
    if event is not None:
        for key in ["EventName", "Location", "Country", "RoundNumber"]:
            try:
                value = event.get(key)
                if value is not None and not pd.isna(value): event_info[key] = str(value)
            except Exception:
                pass

    return {
        "event": event_info, "lap_count": len(laps), "valid_lap_count": len(valid),
        "driver_count": int(laps["Driver"].nunique()) if "Driver" in laps else 0,
        "driver_pace": pace, "tyre_stints": stints,
        "weather_samples": weather, "weather_summary": pd.DataFrame(weather_summary),
        "results": result_table,
        "availability": {
            "Lap data": not laps.empty, "Weather samples": not weather.empty,
            "Session results": not results.empty, "Telemetry loaded": False
        },
        "caveats": [
            "Lap-time summaries describe observed pace, not pure driver skill.",
            "Traffic, fuel load, setup, tyre age and track evolution affect lap times.",
            "Weather values are recorded session samples, not a future forecast.",
            "Team pace is only an imperfect proxy for car capability.",
            "Telemetry and predictive strategy simulation are not implemented yet."
        ]
    }
