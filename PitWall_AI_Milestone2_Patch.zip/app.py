from pathlib import Path
import streamlit as st
import fastf1
import pandas as pd
import plotly.express as px
from src.pitwall.data.fastf1_loader import load_session, enable_cache
from src.pitwall.analytics.race_state import build_race_state

ROOT = Path(__file__).resolve().parent
enable_cache(ROOT / "data" / "cache")
st.set_page_config(page_title="PitWall AI", page_icon="🏎️", layout="wide")
st.title("PitWall AI")
st.caption("Formula 1 race intelligence — observed data, derived metrics and explicit uncertainty.")

with st.sidebar:
    st.header("Session")
    year = st.selectbox("Season", list(range(2026, 2017, -1)), index=0)
    event = st.text_input("Grand Prix / event", "British Grand Prix")
    session_name = st.selectbox("Session", ["R", "Q", "FP3", "FP2", "FP1"])
    load_clicked = st.button("Load session", type="primary", use_container_width=True)

if load_clicked:
    with st.spinner("Loading session data..."):
        try:
            st.session_state["pitwall_session"] = load_session(int(year), event.strip(), session_name)
            st.session_state["pitwall_label"] = f"{year} · {event} · {session_name}"
        except Exception as exc:
            st.error(f"Could not load session: {exc}")

session = st.session_state.get("pitwall_session")
if session is None:
    st.info("Choose a completed season, Grand Prix and session, then click Load session.")
    st.stop()

try:
    state = build_race_state(session)
except Exception as exc:
    st.error(f"Could not build race state: {exc}")
    st.stop()

st.subheader(st.session_state.get("pitwall_label", "Loaded session"))
a, b, c, d = st.columns(4)
a.metric("Lap records", f"{state['lap_count']:,}")
b.metric("Valid timed laps", f"{state['valid_lap_count']:,}")
c.metric("Drivers", f"{state['driver_count']:,}")
d.metric("Weather samples", f"{len(state['weather_samples']):,}")

overview, pace_tab, tyres_tab, weather_tab, results_tab = st.tabs(
    ["Overview", "Driver & car pace", "Tyres & stints", "Weather", "Results & data quality"]
)
with overview:
    st.markdown("### Unified race-state snapshot")
    st.json(state["event"])
    st.dataframe(pd.DataFrame([{"Data source": k, "Available": v} for k, v in state["availability"].items()]),
                 use_container_width=True, hide_index=True)
    st.write("This milestone summarizes available historical session data; it does not yet make strategy recommendations.")

with pace_tab:
    st.markdown("### Observed driver pace")
    pace = state["driver_pace"]
    if pace.empty:
        st.warning("No valid lap times available.")
    else:
        st.dataframe(pace, use_container_width=True, hide_index=True)
        metric = st.selectbox("Compare metric", ["MedianLapSeconds", "BestLapSeconds", "StdDevSeconds", "MedianGapToFastestSeconds"])
        fig = px.bar(pace.sort_values(metric), x="Driver", y=metric, title=f"Driver comparison: {metric}")
        st.plotly_chart(fig, use_container_width=True)
    st.caption("This is not a pure driver ranking: car, traffic, fuel, setup, tyre age and track conditions confound pace.")

with tyres_tab:
    st.markdown("### Tyre and stint summary")
    stints = state["tyre_stints"]
    if stints.empty: st.warning("Tyre/stint data was not available in the expected format.")
    else: st.dataframe(stints, use_container_width=True, hide_index=True)
    st.caption("Descriptive data only; degradation modelling and pit-window simulation come later.")

with weather_tab:
    st.markdown("### Recorded weather samples")
    weather = state["weather_samples"]
    if state["weather_summary"].empty: st.warning("No usable weather measurements returned.")
    else: st.dataframe(state["weather_summary"], use_container_width=True, hide_index=True)
    if not weather.empty:
        choices = [c for c in ["AirTemp", "TrackTemp", "Humidity", "WindSpeed", "Rainfall"] if c in weather]
        if choices and "Time" in weather:
            metric = st.selectbox("Weather variable", choices)
            st.plotly_chart(px.line(weather, x="Time", y=metric, title=f"{metric} during session"), use_container_width=True)
    st.caption("These are recorded samples, not live conditions or a forecast.")

with results_tab:
    st.markdown("### Session results")
    if state["results"].empty: st.warning("No result table available.")
    else: st.dataframe(state["results"], use_container_width=True, hide_index=True)
    st.markdown("### Data quality and limitations")
    for note in state["caveats"]: st.write(f"- {note}")
    with st.expander("Raw data columns"):
        st.write("Lap columns"); st.code(", ".join(map(str, session.laps.columns)))
        st.write("Weather columns"); st.code(", ".join(map(str, session.weather_data.columns)))
        st.write("Result columns"); st.code(", ".join(map(str, session.results.columns)))
